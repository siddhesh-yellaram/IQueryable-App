﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IQueryableApp.Model;

namespace IQueryableApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //Employee e1 = new Employee { Id = 101, Name = "Sal", Salary = 50000, Department = "IT" };
            //Employee e2 = new Employee { Id = 102, Name = "Harry", Salary = 70000, Department = "IT" };
            //Employee e3 = new Employee { Id = 103, Name = "Blinks", Salary = 50000, Department = "Sales" };
            AurionProDBContext db = new AurionProDBContext();
            //db.Employees.Add(e1);
            //db.Employees.Add(e2);
            //db.Employees.Add(e3);
            IQueryable<Employee> list = db.Employees.Where(d => d.Department.Equals("IT"));
            foreach(var emp in list)
            {
                Console.WriteLine(emp.Name);
            }
            db.SaveChanges();
        }
    }
}
